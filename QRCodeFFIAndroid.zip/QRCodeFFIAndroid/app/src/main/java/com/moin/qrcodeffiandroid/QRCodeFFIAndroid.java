package com.moin.qrcodeffiandroid;

import android.content.Context;
import android.content.Intent;

import com.konylabs.android.KonyMain;
import com.konylabs.vm.Function;



public class QRCodeFFIAndroid {
    private static Context context = (Context)KonyMain.getActivityContext();
    public static void init(Function callback) {
        QRCodeActivity.qrScanCallBack = callback;
        context.startActivity(new Intent(context, QRCodeActivity.class));

        }
    }