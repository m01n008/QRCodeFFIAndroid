package com.moin.qrcodeffiandroid;

import com.journeyapps.barcodescanner.CaptureActivity;

public class AnyOrientationCaptureActivity extends CaptureActivity {
}
