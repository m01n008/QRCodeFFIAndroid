package com.moin.qrcodeffiandroid;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;
import com.journeyapps.barcodescanner.BarcodeEncoder;
import com.konylabs.vm.Function;

public class QRCodeActivity extends AppCompatActivity {

    public static Function qrScanCallBack = null;
    private static final int PERMISSION_REQUEST_CAMERA = 1;
    private EditText scannedData;
    private ImageView imageViewQrCode;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.qrcode_activity);
        scannedData = findViewById(R.id.scannedData);
        imageViewQrCode = findViewById(R.id.qrCode);

    }
    public void onScanQRBtnClick(View view){
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CAMERA}, PERMISSION_REQUEST_CAMERA);
        }
        else{
            initQRCodeScanner();
        }
    }

    public void onGenerateQRCodeClick(View view){
        try {
            BarcodeEncoder barcodeEncoder = new BarcodeEncoder();
            Bitmap bitmap;
            String scannedText = String.valueOf(scannedData.getText());
            if(scannedText != null && !scannedText.isEmpty()){
                bitmap = barcodeEncoder.encodeBitmap(scannedText, BarcodeFormat.QR_CODE, 400, 400);
                imageViewQrCode.setImageBitmap(bitmap);
            }
            else{
                Toast.makeText(this, "Text Field is empty, please enter text", Toast.LENGTH_LONG).show();
            }
        } catch(Exception e) {

        }
    }

    private void initQRCodeScanner() {
        // Initialize QR code scanner here
        IntentIntegrator integrator = new IntentIntegrator(this);
        integrator.setDesiredBarcodeFormats(IntentIntegrator.QR_CODE);
        integrator.setCaptureActivity(AnyOrientationCaptureActivity.class);
        integrator.setOrientationLocked(true);
        integrator.setPrompt("Scan a QR code");
        integrator.initiateScan();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == PERMISSION_REQUEST_CAMERA) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                initQRCodeScanner();
            } else {
                Toast.makeText(this, "Camera permission is required", Toast.LENGTH_LONG).show();
                finish();
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        IntentResult result = IntentIntegrator.parseActivityResult(requestCode, resultCode, data);
        if (result != null) {
            if (result.getContents() == null) {
                Toast.makeText(this, "Scan cancelled", Toast.LENGTH_LONG).show();
            } else {
                scannedData.setText(result.getContents().toString());
                Toast.makeText(this,"returning to kony",Toast.LENGTH_SHORT).show();
                String returndata[] = new String[1];
                returndata[0] = scannedData.getText().toString();
                try {
                    qrScanCallBack.execute(returndata);
                } catch (Exception e) {
                    e.printStackTrace();
                }
              //  finish();
                Toast.makeText(this, "Scanned: " + result.getContents(), Toast.LENGTH_LONG).show();
            }
        } else {
            super.onActivityResult(requestCode, resultCode, data);
        }
    }
}